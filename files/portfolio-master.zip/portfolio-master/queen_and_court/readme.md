Module that handles the all the judging phases of Queen and Court selection for the Rose Parade. 
-Each queen is an entity
-Able to pull a CSV of all queen scores
