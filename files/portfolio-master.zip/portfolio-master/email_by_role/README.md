EMAIL by Role

This was a simple module that allowed admin's to send emails out to different users depending on their role.