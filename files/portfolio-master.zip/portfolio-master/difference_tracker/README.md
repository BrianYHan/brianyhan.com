Difference Tracker

This module was made for the Tournament of Roses Foundation as part of the parade application workflow. The client needed a way to track all the changes in applications and mark the characters line by line if they had been editted in the last week. It did this by creating a display-type node while erasing duplicate entries from the same applicant. 