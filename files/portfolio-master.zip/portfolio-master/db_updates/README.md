DB Updater

This module allows our client (a semi-truck dealer) to keep their mobile site's online inventory up to date by connecting and updating their website's nodes using their their external database.