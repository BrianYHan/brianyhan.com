<div class="mainContainer">
  <?php if($page['header']) {echo(render($page['header']));} ?>
  <?php if($page['menubar']) {echo(render($page['menubar']));} ?>
  <?php if($title && !$is_front) {echo('<h2 class="pageTitle">' . render($title) . '</h2>');} ?>
  <?php if($tabs) {echo(render($tabs));} ?>
  <?php if($messages) {echo($messages);} ?>
  <?php if($page['content']) {echo(render($page['content']));} ?>
  <?php if($page['sidebar_first']) {echo(render($page['sidebar_first']));} ?>
  <?php if($page['footer']) {echo(render($page['footer']));} ?>
</div>
<div id="greatmatter_logo" style="text-align: center; margin-top: 20px;"><a href="http://www.greatmatter.com/"><img src="http://c428923.r23.cf2.rackcdn.com/gmlogosmall.png" alt="Powered by Great Matter" style="height: 29px; width: 60px; border: 0px; margin-top: 10px;"/></a></div>
<div style="clear: both"></div>
