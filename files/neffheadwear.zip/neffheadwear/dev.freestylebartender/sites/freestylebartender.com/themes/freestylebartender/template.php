<?php
  function freestylebartender_preprocess_html(&$variables){
    $theme_path = base_path() . path_to_theme();
    drupal_add_css($theme_path . '/css/normalize.css', array(
      'type' => 'file',
      'group' => CSS_SYSTEM,
      'every_page' => TRUE,
      'weight' => -1000,
    ));

    drupal_add_html_head_link(array(
      'rel' => 'stylesheet',
      'type' => 'text/css',
      'href' => '//fonts.googleapis.com/css?family=Montserrat:400,700|Oswald:400,300,700',
    ));

    drupal_add_html_head(unserialize(base64_decode(
      'YTozOntzOjU6IiN0eXBlIjtzOjg6Imh0bWxfdGFn' . 
      'IjtzOjQ6IiN0YWciO3M6NDoibWV0YSI7czoxMToi' . 
      'I2F0dHJpYnV0ZXMiO2E6Mjp7czo0OiJuYW1lIjtz' . 
      'Ojc6ImNyZWF0b3IiO3M6NzoiY29udGVudCI7czox' . 
      'MjoiR3JlYXQgTWF0dGVyIjt9fQ'
    )), 'themename_credit');

    drupal_add_html_head(array(
      '#tag' => 'meta',
      '#attributes' => array(
        '#name' => 'viewport',
        'content' => 'width=device-width, initial-scale=1',
      ),
    ), 'viewport');

    drupal_add_css('//fonts.googleapis.com/css?family=Roboto+Condensed:300italic,400italic,700italic,400,300,700|Roboto:300italic,300,400italic,400,100italic,100,500,700,500italic,900,700italic,900italic', 'external');
  }

/** 
 * Implements hook_form_alter
 */
 function freestylebartender_form_alter(&$form, &$form_state, $form_id){
  // If form-submit says 'Add to cart', change text to 'Buy Now' 
  // dsm($form);
  // dsm($form_id);
  $form_id_split = strpos($form_id, 'commerce_cart_add_to_cart_form');
  if($form_id_split !== false){
    if($form['submit']['#value'] == 'Add to cart'){
      $form['submit']['#value'] = t('Buy Now');
    }
  }

  

  
 }
