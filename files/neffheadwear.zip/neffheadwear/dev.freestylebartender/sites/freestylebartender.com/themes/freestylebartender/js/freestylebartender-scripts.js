(function ($) {
	$(document).ready(function(){
		// Open external links in new windows.
    $('a').click(function(){
      if($(this).attr('href').slice(0,7) == 'http://' || $(this).attr('href').slice(0,8) == 'https://' || $(this).attr('href').slice(0,7) == 'mailto:'){
        window.open($(this).attr('href'));
        return false;
      }
    });
	});
})(jQuery);