<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>
    <meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
    <title>
      <?php print $head_title; ?>
    </title>
    <?php print $head; ?>
    
    <style type="text/css">
      body{
        font-family: Arial, Helvetica, sans-serif;
        font-size: 12px;
        background-color: #ffffff;
        background-repeat: repeat-x;
        color: #717174;
        text-align: center;
      }
      
      img{
        border: 0px;
      }

      h4{
        font-size: 10px;
        font-weight: normal;
        color: #eeeeee;
      }
      
      a:link,
      a:visited,
      a:active,
      a:hover{
        color: #000000;
      }
    </style>
  </head>
  <body class="<?php print $classes ?>">
  <?php
    $url = 'http://images.greatmatter.com/under_construction_logo.gif';
    if($logo){
      $url = $logo;
    }
  ?>
    <img style="width: 300px" src="<?php print $url; ?>" alt="Site Logo" /><br/>
    <h2><?php print $content ?></h2>
    <div id="footer"><?php print $footer ?></div>
  </body>
</html>