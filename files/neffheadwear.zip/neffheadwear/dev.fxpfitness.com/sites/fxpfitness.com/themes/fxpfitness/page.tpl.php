<div class="mainContainer">
  <?php if($page['header']) {echo(render($page['header']));} ?>
  <?php if($page['content']) {echo(render($page['content']));} ?>
  <?php if($page['sidebar_first']) {echo(render($page['sidebar_first']));} ?>
  <?php if($page['super_footer']) {echo(render($page['super_footer']));} ?>
  <?php if($page['footer']) {echo(render($page['footer']));} ?>
</div>
