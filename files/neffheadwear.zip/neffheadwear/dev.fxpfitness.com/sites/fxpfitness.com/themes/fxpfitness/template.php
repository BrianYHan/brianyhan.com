<?php
  /**
   * Implementation of hook_preprocess_html
   **/
  function fxpfitness_preprocess_html(&$variables){
    drupal_add_js('jQuery.extend(Drupal.settings, { "pathToTheme": "' . path_to_theme() . '" });', 'inline');
    drupal_add_css('//ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/themes/base/jquery-ui.css', 'external');
    drupal_add_js('//ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js', 'external');
    drupal_add_html_head_link(array(
      'rel' => 'stylesheet',
      'type' => 'text/css',
      'href' => '//fonts.googleapis.com/css?family=Montserrat:400,700|Oswald:400,300,700',
    ));

    $itemToAdd = array(
      '#type' => 'html_tag',
      '#tag' => 'meta',
      '#attributes' => array(
        'name' =>  'creator',
        'content' => 'Great Matter',
      ),
    );

    $itemToAdd = array(
      '#type' => 'html_tag',
      '#tag' => 'meta',
      '#attributes' => array(
        'name' =>  'google-site-verification',
        'content' => 'o57cG81EZad8Z4O-_xwik6q7iNvMyqB3y8WHxZQEgu0',
      ),
    );

    drupal_add_html_head($itemToAdd, 'google_site_verification');

    drupal_add_html_head(unserialize(base64_decode(
      'YTozOntzOjU6IiN0eXBlIjtzOjg6Imh0bWxfdGFn' . 
      'IjtzOjQ6IiN0YWciO3M6NDoibWV0YSI7czoxMToi' . 
      'I2F0dHJpYnV0ZXMiO2E6Mjp7czo0OiJuYW1lIjtz' . 
      'Ojc6ImNyZWF0b3IiO3M6NzoiY29udGVudCI7czox' . 
      'MjoiR3JlYXQgTWF0dGVyIjt9fQ'
    )), 'fxpfitness_credit');

    // Google Experiment
    if(1==0){
      $itemToAdd = array(
        '#type' => 'markup',
        '#markup' => "<!-- Google Analytics Content Experiment code -->
  <script data-cfasync=\"false\">function utmx_section(){}function utmx(){}(function(){var
  k='85745337-1',d=document,l=d.location,c=d.cookie;
  if(l.search.indexOf('utm_expid='+k)>0)return;
  function f(n){if(c){var i=c.indexOf(n+'=');if(i>-1){var j=c.
  indexOf(';',i);return escape(c.substring(i+n.length+1,j<0?c.
  length:j))}}}var x=f('__utmx'),xx=f('__utmxx'),h=l.hash;d.write(
  '<sc'+'ript src=\"'+'http'+(l.protocol=='https:'?'s://ssl':
  '://www')+'.google-analytics.com/ga_exp.js?'+'utmxkey='+k+
  '&utmx='+(x?x:'')+'&utmxx='+(xx?xx:'')+'&utmxtime='+new Date().
  valueOf()+(h?'&utmxhash='+escape(h.substr(1)):'')+
  '\" type=\"text/javascript\" charset=\"utf-8\"><\/sc'+'ript>')})();
  </script><script>utmx('url','A/B');</script>
  <!-- End of Google Analytics Content Experiment code -->
  ",
        '#weight' => -99999,
      );

      $pagesForExperiments = array(
        'node/5',
        'landing-page-1',
        'landing-page-2',
      );

      if(in_array(current_path(), $pagesForExperiments)){
        global $user;
        if($user->uid != 1){
          drupal_add_html_head($itemToAdd, 'google_analytics_experiment');
        }
      }
    }

    // $path = drupal_get_path('theme', 'fxpfitness');
    // drupal_add_js($path . '/js/purechat.js', array('scope' => 'bottom_scripts', 'weight' => -1, 'preprocess' => FALSE));
  }

  /** 
   * Implementation of hook_process_html()
   */
  function fxpfitness_process_html(&$vars) {
    $vars['bottom_scripts'] = drupal_get_js('bottom_scripts');
  }

  /**
   * Implementation of hook_preprocess_node
   **/
  // function fxpfitness_preprocess_node(&$vars) {
  //   if (variable_get('node_submitted_' . $vars['node']->type, TRUE)) {
  //     $date = format_date($vars['node']->created, 'very_long_date_only');
  //     $vars['submitted'] = t('by !username on !datetime', array(
  //       '!username' => $vars['name'],
  //       '!datetime' => $date,
  //     ));
  //   }
  // }


/**
 * Implementation of hook_form_alter
 */

function fxpfitness_form_alter(&$form, &$form_state, $form_id){
  //dsm($form);
  if(substr($form_id, 0, strlen('commerce_cart_add_to_cart_form')) == 'commerce_cart_add_to_cart_form'){
    if(isset($form['quantity'])){
      unset($form['quantity']);
      $form['quantity']['#type'] = 'select';
      $form['quantity']['#datatype'] = 'integer';
      $form['quantity']['#title'] = t('Quantity');
      $form['quantity']['#multiple'] = false;
      $form['quantity']['#weight'] = 45;
      $form['quantity']['#options'] = array(
        1 => 1,
        2 => 2,
        3 => 3,
        4 => 4,
        5 => 5,
        6 => 6,
        7 => 7,
        8 => 8,
        9 => 9,
        10 => 10,
      );
      if(isset($form['attributes']['field_hoop_color'])){
        // $form['attributes']['field_hoop_color']['#options'][''] = t('Select Color');
        // $form['attributes']['field_hoop_color']['#default_value'] = '';
        // $form['attributes']['field_hoop_color']['#attributes']['class'][] = 'hoop-color-select';
        $form['attributes']['#weight'] = 46;
        $form['#validate'][] = 'fxpfitness_form_add_to_cart_form_validate';
      }
    }
  }
}

function fxpfitness_form_add_to_cart_form_validate(&$form, &$form_state){
  if(isset($form_state['values']['attributes']['field_hoop_color'])){
    if($form_state['values']['attributes']['field_hoop_color'] == ''){
      form_set_error('field_hoop_color', t('Please choose a color.'));
    }
  }
}