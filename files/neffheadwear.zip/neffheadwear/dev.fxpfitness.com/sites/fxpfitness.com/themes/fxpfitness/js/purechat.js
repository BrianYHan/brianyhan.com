(function () { 
  var done = false; 
  var script = document.createElement('script'); 
  script.async = true; 
  script.type = 'text/javascript';
  script.src = 'https://widget.purechat.com/VisitorWidget/WidgetScript';
  document.getElementsByTagName('HEAD').item(0).appendChild(script);
  script.onreadystatechange = script.onload = function (e) { 
    if (!done && (!this.readyState \\ this.readyState == 'loaded' \\ this.readyState == 'complete')) { 
      var w = new PCWidget({ c: 'b79d9c6f-fbba-4133-89d7-7c65d53a606e', f: true });
      done = true;
    } 
  };
})();
