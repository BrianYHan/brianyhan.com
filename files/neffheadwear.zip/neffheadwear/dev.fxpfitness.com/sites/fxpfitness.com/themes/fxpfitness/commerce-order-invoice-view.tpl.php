<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
  </head>
  <body>
    <table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#CCC">
      <tr>
        <td>
          <table width="100%" border="0" cellspacing="0" cellpadding="5" align="center" bgcolor="#FFF" style="font-family: verdana, arial, helvetica; font-size: 10px;">
            <tr>
              <td>
                <table width="100%" border="0" cellspacing="0" cellpadding="0" style="font-family: verdana, arial, helvetica; font-size: 11px;">
                  <tr>
                    <td nowrap="nowrap" style="line-height: 1.6em;" valign="middle" align=center>
											<!-- Invoice Header -->
											<img src="<?php echo(url(drupal_get_path('theme', 'fxpfitness') . '/images/fxp_logo_singleV4.jpg', array('absolute' => true))); ?>" />
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td>
                <table width="100%" border="0" cellspacing="0" cellpadding="0" style="font-family: verdana, arial, helvetica; font-size: 11px;">
                  <tr>
                    <th colspan="2"><?php print t('Order Summary'); ?></th>
                  </tr>
                  <tr>
                    <td colspan="2">

                      <table class="details" width="100%" cellspacing="0" cellpadding="0" style="font-family: verdana, arial, helvetica; font-size: 1em;">
                        <tr>
                          <td valign="top" width="50%">
                            <br/>
                            <b><?php print t('Account No:'); ?></b> <?php print $info['order_uid']; ?><br/>
                            <br/>
                            <b><?php print t('Order Date:'); ?></b> <?php print date('j F, Y', $info['order_created']); ?><br/>
                            <br/>
                            <b><?php print t('Billing Address:'); ?></b><br />
                            <?php print isset($info['customer_billing']) ? $info['customer_billing'] : ''; ?><br />
                          </td>
                          <td valign="top" width="50%">
                            <br/>
                            <b><?php print t('Web Order No:'); ?></b> <?php print $info['order_number']; ?><br/>
                            <br/>
                            <b><?php print t('Email Address:'); ?></b> <?php print $info['order_mail']; ?><br/>
                            <br/>
                            <b><?php print t('Shipping Address:'); ?></b><br />
                            <?php print isset($info['customer_shipping']) ? $info['customer_shipping'] : ''; ?><br />
                          </td>
                        </tr>
                      </table>

                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td>
                <?php
                  $view = views_get_view('commerce_cart_summary');
                  $view->set_display('attachment_1');
                  $view->set_arguments(array($info['order_number']));
                  $view->pre_execute();
                  $view->execute();
                  print $view->render();

                  $rows = commerce_moulton_order_totals($order);

                  echo(theme('table', array(
                    'header' => array('', ''),
                    'rows' => $rows,
                    'attributes' => array(
                      'class' => array('subtotal_table'),
                    ),
                  )));
                ?>
              </td>
            </tr>
            <tr>
              <td>
                <table>
                  <tr>
                    <td colspan="2" style="background: #EEE; color: #666; padding: 1em; font-size: 0.9em; line-height: 1.6em; border-top: #CCC 1px dotted; text-align: center;">
                      <!-- Invoice Header -->
											Thank you for your order. All orders ship as soon as possible, within 3 business days. If you have any changes or questions regarding your order please contact us at <a href="mailto:customerservice@fxpfitness.com">customerservice@fxpfitness.com</a> or (844) 496-8247.
                      <table style="width: 100%">
                        <tr>
                          <td style="width: 50%; font-size: 12pt; font-weight: bold">
                            To enhance your FXP Hula Hoop&reg; System we suggest <a href="<?php echo(url('products/life-diet-nutri-pack', array('absolute' => true))); ?>">adding our Life Diet Nutri-Pack</a> to your order for just $49.95.
                          </td>
                          <td>
                            <a href="<?php echo(url('products/life-diet-nutri-pack', array('absolute' => true))); ?>"><img src="<?php echo(url(drupal_get_path('theme', 'fxpfitness') . '/images/nutripack_image.jpg', array('absolute' => true))); ?>" /></a>
                          </td>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>
