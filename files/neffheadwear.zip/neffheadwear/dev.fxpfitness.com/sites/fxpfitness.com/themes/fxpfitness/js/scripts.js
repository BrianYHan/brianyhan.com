(function($) {
    $(document).ready(function() {
        //Change the text to 'Register Now' for all training courses
        // if ($('.node-type-product-display .view-product-display .views-row .views-field-title .field-content').toLowerCase.search('train') < 1 || 1 == 1) {
        //     console.log('yes');
        //     $('.node-type-product-display .commerce-add-to-cart #edit-submit').value('Register Now');
        // }

        //Unhide refund policy for certifications on the checkout page
        if($('body').hasClass('page-checkout')){
            $('.views-field-type-1').each(function(){
                var typeOfProduct = $.trim($(this).text());
                console.log(typeOfProduct);
                if(typeOfProduct == 'Certifications'){
                    $('#edit-extra-pane-node-132').show();
                }
            });
        }

        // Move Your Trainer ID block into header container for "Partner Discounts"
        if($('body').hasClass('page-partner-discounts')){
            $('#block-block-8').appendTo($('.trainer-id-block-container'));
        }
        // Move Your Trainer ID block under header container in "My Trainer Dashboard"
        if($('body').hasClass('page-node-55')){
            $('#block-block-8').appendTo($('#block-superfish-7 h2'));
        }

        // Change the select boxes in the checkout pages.
        $('.page-checkout .form-select').selectBoxIt();
        reorganizeProductPage();

        // Adjust the formatting of the "Never Miss a Fitness Tip" email item.
        // if($('.region-content .block-mailchimp-lists h2').length > 0){
        //   $('.region-content .block-mailchimp-lists h2').html($('.region-content .block-mailchimp-lists h2').html().replace('Fitness Tip', '<u>Fitness Tip</u>'));
        // }
        higlightBlockAdjust();


        //Add Active class to Details tab of Life Diet Book and Life Diet Nutri Pack Pages
        addActiveClassToLifeDietTabs('.page-node-28 #quicktabs-product_information li.last');
        addActiveClassToLifeDietTabs('.page-node-29 #quicktabs-product_information li.last');

        // Format the on-click functionality of the fields for the emailer.
        $('.pane-mailchimp-lists-fitness-tip .form-text, .block-mailchimp-lists .form-text').addClass('defaultValue');
        $('.pane-mailchimp-lists-fitness-tip .form-text, .block-mailchimp-lists .form-text').attr('original_value', 'enter email address');
        $('.pane-mailchimp-lists-fitness-tip .form-text, .block-mailchimp-lists .form-text').each(function() {
            $(this).val($(this).attr('original_value'));
        });

        $('.pane-mailchimp-lists-fitness-tip .form-text, .block-mailchimp-lists .form-text').click(function() {
            if ($(this).val() == $(this).attr('original_value')) {
                $(this).val('');
                $(this).removeClass('defaultValue');
            }
        });

        $('.pane-mailchimp-lists-fitness-tip .form-text, .block-mailchimp-lists .form-text').blur(function() {
            if ($(this).val() == '') {
                $(this).val($(this).attr('original_value'));
                $(this).addClass('defaultValue');
            }
        });

        $('.mailchimp-lists-user-subscribe-form').submit(function() {
            $('.pane-mailchimp-lists-fitness-tip .form-text, .block-mailchimp-lists .form-text').each(function() {
                if ($(this).val() == $(this).attr('original_value')) {
                    $(this).val('');
                }
            });
        });

        // Add any "trial" or "30 day money back" labels.
        if (1 == 1) {
            $('.view-Slideshow .views-field-field-image .field-content, .page-node.node-type-product-display .field-content').each(function() {
                if ($(this).hasClass('30_day_free_trial')) {
                    $(this).closest('.views-row').prepend('<div class="image_30_day_free_trial"></div>');
                }
                if ($(this).hasClass('30_day_money_back')) {
                    $(this).closest('.views-row').prepend('<div class="image_30_day_money_back"></div>');
                }
            });
        }

        // Add summer sale labels.
        if (1 == 1) {
            $('.view-Slideshow .views-field-field-image .field-content, .page-node.node-type-product-display .field-content').each(function() {
                if ($(this).hasClass('summer_sale_10')) {
                    $(this).closest('.views-row').prepend('<div class="image_summer_sale_10"></div>');
                }
                if ($(this).hasClass('summer_sale_15')) {
                    $(this).closest('.views-row').prepend('<div class="image_summer_sale_15"></div>');
                }
                if ($(this).hasClass('summer_sale_20')) {
                    $(this).closest('.views-row').prepend('<div class="image_summer_sale_20"></div>');
                }
            });
        }

        // Add summer sale labels to the product grid
        if (1 == 1) {
            $('.view-product-catalog .field-content .views-field-field-image').each(function() {
                if ($(this).hasClass('summer_sale_10')) {
                    $(this).prepend('<div class="image_summer_sale_10"></div>');
                }
                if ($(this).hasClass('summer_sale_15')) {
                    $(this).prepend('<div class="image_summer_sale_15"></div>');
                }
                if ($(this).hasClass('summer_sale_20')) {
                    $(this).prepend('<div class="image_summer_sale_20"></div>');
                }
            });
        }

        // Convert cart "Update Cart" into a URL looking thing.
        $('.view-commerce-cart-form .form-submit[value="Update cart"]').addClass('updateCart');

        // Ensure external links and links to PDFs open in a new window.
        $('a').click(function() {
            if ($(this).closest('#block-views-highlight-blocks-block, #block-views-slideshow-block, #block-views-slideshow-block-1, #block-views-slideshow-block-2').length > 0) {
                return;
            }
            if ($(this).attr('href').slice(0, 7) == 'http://' || $(this).attr('href').slice(0, 8) == 'https://' || $(this).attr('href').slice(0, 7) == 'mailto:' || $(this).attr('href').indexOf('.pdf') > 0) {
                window.open($(this).attr('href'));
                return false;
            }
        });

        // Add the appropriate banners to the page.
        if ($('body').hasClass('node-type-product-display')) {
            $('.panel-col-first').append('<div class="special-offer-banner"></div>');
            $('.panel-col-first').append('<div class="image_30_day_money_back_bottom_banner"></div>');
            //updateOfferBanner();
        }

        // Allow selection of a product to change the selected image on the left.
        onColorSelect();

        // Ensure all instances of FXP® or FXP&reg; are made smaller (with code!)
        $('body *').replaceText(/FXP®/g, 'FXP<sup>®</sup>');
        $('body *').replaceText(/FXP&reg;/g, 'FXP<sup>&reg;</sup>');

        // Make the contact form fields go inside.
        $('#webform-client-form-34 .form-text, #webform-client-form-34 .form-textarea, #webform-client-form-52 .form-text, #webform-client-form-52 .form-textarea').each(function() {
            checkName($(this));
        });

        $('#webform-client-form-34 .form-text, #webform-client-form-34 .form-textarea, #webform-client-form-52 .form-text, #webform-client-form-52 .form-textarea').focus(function() {
            if ($(this).val() == getLabel($(this))) {
                $(this).val('');
                $(this).removeClass('gray');
            }
        });

        $('#webform-client-form-34 .form-text, #webform-client-form-34 .form-textarea, #webform-client-form-52 .form-text, #webform-client-form-52 .form-textarea').blur(function() {
            if ($(this).val() == getLabel($(this)) || $(this).val() == '') {
                $(this).addClass('gray');
                $(this).val(getLabel($(this)));
            } else {}
        });
        $('#webform-client-form-34 .form-select, #webform-client-form-52 .form-select').selectBoxIt();

        var ajax_inprocess = false;

        // END OF READY
    });

    $(document).ajaxStart(function() {
        $('.form-submit').attr('disabled', true);
        // Prevents first click error
        $('a').one('click', false);
        ajax_inprocess = true;

    });

    $(document).ajaxComplete(function() {
        $('.form-submit').removeAttr('disabled');
        ajax_inprocess = false;
        $('.page-checkout .form-select').selectBoxIt();
        reorganizeProductPage();
        onColorSelect();
    });

    /**
     * Allow selection of a product to change the selected image on the left.
     */
    function onColorSelect() {
        $('select[name="attributes[field_hoop_color]"]').on('change', function() {
            $('.views-slideshow-pager-fields .views-slideshow-pager-field-item').eq($(this).prop("selectedIndex")).click();
        });
    }

    /**
     * Update the offer banner
     */
    function updateOfferBanner() {
        if ($('#edit-attributes-field-special-offer').length > 0) {
            specialOffer = $('#edit-attributes-field-special-offer').val();
            $('.special-offer-banner').removeClass().addClass('special-offer-banner');
            $('.special-offer-banner').addClass(specialOffer);
        }
    }

    /**
     * Makes the Highlight blocks the same height as each other.
     */
    function higlightBlockAdjust() {
        // Start with the title
        maxHeight = 0;
        $('#block-views-highlight-blocks-block .views-field-title').each(function() {
            maxHeight = Math.max(maxHeight, $(this).height());
        });
        $('#block-views-highlight-blocks-block .views-field-title').css('height', maxHeight + 'px');

        // Do the body
        maxHeight = 0;
        $('#block-views-highlight-blocks-block .views-field-body').each(function() {
            maxHeight = Math.max(maxHeight, $(this).height());
        });
        $('#block-views-highlight-blocks-block .views-field-body').css('height', maxHeight + 'px');
    }

    /**
     * Reorganize the product page
     */
    function reorganizeProductPage() {
        // Convert messages into modals.
        if (1 == 1) {
            $('.messages').each(function() {
                // Ensure that if the message contains any information about the cart, we need to make it a bit different.
                if ($('.messages').html().indexOf('Congrats!') >= 0) {
                    $('.messages h2').html('Added to your Cart');
                } else if ($('.messages h2').html() == 'Status message') {
                    $('.messages h2').html('FYI');
                } else {}

                $('.messages').append('<div class="close"></div>');
                $('.messages .close').click(function() {
                    $.modal.close();
                });
                $('.messages').modal({
                    onClose: function(dialog) {
                        $.modal.close();
                        $('.messages').hide();
                        $('.messages').remove();
                    },
                    overlayCss: {
                        backgroundColor: '#000000'
                    },
                    overlayClose: true
                });
            });
        }

        // Add Shipping and handling information.
        if ($('.commerce-product-field-field-initial-price').length > 0) {
            $('.commerce-product-field-field-initial-price .field-items .field-item').append(' plus S&H');
        }

        if ($('body').hasClass('node-type-product-display') && $('body').hasClass('page-node')) {
            $('.form-item-attributes-field-hoop-color option').each(function() {
                $(this).attr('data-iconurl', Drupal.settings.basePath + Drupal.settings.pathToTheme + '/images/square_' + $(this).val() + '.png');
            });

            $('.form-select').selectBoxIt({
                autoWidth: false
            });

            if ($('.commerce-add-to-cart .attribute-widgets').length > 0) {
                $('.commerce-product-field-field-special-offers').hide().clone().show().insertAfter($('.commerce-add-to-cart .attribute-widgets'));
                $('.commerce-product-field-field-initial-price').hide().clone().show().insertAfter($('.commerce-add-to-cart .attribute-widgets'));
                $('.commerce-product-field-commerce-price').hide().clone().show().insertAfter($('.commerce-add-to-cart .attribute-widgets'));
                $('.commerce-product-field-field-regular-price').hide().clone().show().insertAfter($('.commerce-add-to-cart .attribute-widgets'));
            } else {
                $('.commerce-product-field-field-special-offers').hide().clone().show().insertAfter($('.commerce-add-to-cart .form-item-quantity'));
                $('.commerce-product-field-field-initial-price').hide().clone().show().insertAfter($('.commerce-add-to-cart .form-item-quantity'));
                $('.commerce-product-field-commerce-price').hide().clone().show().insertAfter($('.commerce-add-to-cart .form-item-quantity'));
                $('.commerce-product-field-field-regular-price').hide().clone().show().insertAfter($('.commerce-add-to-cart .form-item-quantity'));
            }

            $('.commerce-product-field-commerce-price .field-label').html('Item price:&nbsp;');
            $('.commerce-product-field-field-initial-price .field-label').html('Today\'s price:&nbsp;');
            $('.field-name-field-description .field-label').html('Details');
            // $('.commerce-add-to-cart .form-submit').clone().appendTo('.node-product-display .field-name-field-description').click(function(){
            //   $('.commerce-add-to-cart').submit();
            // });
        }
    }

    function addActiveClassToLifeDietTabs(el) {
        $(el).addClass('active');
        $('#quicktabs-tabpage-product_information-1').removeClass('quicktabs-hide');
    }

    function checkName(thisItem) {
        var label = getLabel(thisItem);

        if (thisItem.val() == '') {
            thisItem.val(label);
        }

        if (thisItem.val() == label) {
            thisItem.addClass('gray');
        }
    }

    function getLabel(thisItem) {
        var label = $('label[for="' + thisItem.attr('id') + '"]').html().toUpperCase().replace(/<.*?>|\*|/g, '').trim();
        return label;
    }
})(jQuery);